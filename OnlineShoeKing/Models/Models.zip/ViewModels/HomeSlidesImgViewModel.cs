﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineShoeKing.Models
{
    public class HomeSlidesImgViewModel
    {
        public string ImageUrl { get; set; }
    }
}