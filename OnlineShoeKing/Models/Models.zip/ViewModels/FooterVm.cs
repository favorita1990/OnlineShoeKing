﻿
namespace OnlineShoeKing.Models
{
    public class Footer
    {
        public int CustomersCount { get; set; }
        public int MenCount { get; set; }
        public int WomenCount { get; set; }
    }
}